#include "hc32_ddl.h"
#include <rtthread.h>

/* LED1 Port/Pin definition */
#define  LED1_PORT        	(PortB)
#define  LED1_PIN         	(Pin14)

/* LED1 */
void LED1_TOGGLE(void)
{
	PORT_Toggle(LED1_PORT, LED1_PIN);
}

void LED1_INIT(void)
{
    stc_port_init_t stcPortInit;

    /* configuration structure initialization */
    MEM_ZERO_STRUCT(stcPortInit);

    stcPortInit.enPinMode 	= Pin_Mode_Out;
    stcPortInit.enExInt 	= Enable;
    stcPortInit.enPullUp 	= Enable;

    /* LED1 Port/Pin initialization */
    PORT_Init(LED1_PORT, LED1_PIN, &stcPortInit);
}

int32_t main(void)
{
	LED1_INIT();

    while(1)
    {
		rt_thread_mdelay(5000);
		LED1_TOGGLE();		
    };
}

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
