#ifndef DRV_UART_H
#define DRV_UART_H

int CLK_Init(void);
void uart1_init(void);

#endif




