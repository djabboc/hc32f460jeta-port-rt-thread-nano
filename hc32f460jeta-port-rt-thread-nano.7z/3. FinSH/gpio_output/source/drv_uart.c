#include "hc32_ddl.h"
#include "hc32f460_utility.h"

#define UART1_TX_PORT	PortA
#define UART1_RX_PORT	PortA
#define UART1_TX_PIN	Pin00
#define UART1_RX_PIN	Pin01
#define UART1_RX_FUNC  	(Func_Usart1_Rx)
#define UART1_TX_FUNC   (Func_Usart1_Tx)

static void uart1_rx_callback()
{
	/* Do Nothing */;
}

static void uart1_tx_callback()
{
	/* Do Nothing */;
}

void uart1_init(void)
{
    /**------------------------- ʹ�ܴ���ʱ�� -----------------------------**/
    PWC_Fcg1PeriphClockCmd(PWC_FCG1_PERIPH_USART1, Enable);

    /**------------------------- �������Ź��� -----------------------------**/    
    PORT_SetFunc(UART1_RX_PORT, UART1_RX_PIN, UART1_RX_FUNC, Disable); // �������� RX ����
    PORT_SetFunc(UART1_TX_PORT, UART1_TX_PIN, UART1_TX_FUNC, Disable); // �������� TX ����

    /**------------------------- �������� ---------------------------------**/    
    stc_port_init_t stcPortInit;

    MEM_ZERO_STRUCT(stcPortInit);
	
    stcPortInit.enPinMode 	    = Pin_Mode_Out; // TX ���ģʽ
	stcPortInit.enExInt 	    = Disable;
	stcPortInit.enPullUp 	    = Disable;
	stcPortInit.enPinDrv 	    = Pin_Drv_H;
	
    PORT_Init(UART1_TX_PORT, UART1_TX_PIN, &stcPortInit);

    /**------------------------- ���ô��� ---------------------------------**/
    const stc_usart_uart_init_t stcInitCfg =
    {
        UsartIntClkCkNoOutput,			// ѡ���ڲ�ʱ��Դ�������ʱ��
        UsartClkDiv_64,					// Ԥ��Ƶϵ�� 64
        UsartDataBits8,					// ����λ 8
        UsartDataLsbFirst,				// LSB First
        UsartOneStopBit,				// ֹͣλ 1
        UsartParityNone,				// У��λ None
        UsartSampleBit16,				// �������� 16
        UsartStartBitFallEdge,			// �����½���ʱ��ʼ
        UsartRtsEnable,					// ʹ�� RTS
    };
    
    USART_UART_Init(M4_USART1, &stcInitCfg);
    USART_SetBaudrate(M4_USART1, 9600);	 // ���ò����� 9600

    /**------------------------- ���ô��� RX �ж� -------------------------**/
    stc_irq_regi_conf_t stcIrqRegiCfg;
    
    MEM_ZERO_STRUCT(stcIrqRegiCfg);

	stcIrqRegiCfg.enIntSrc 		= INT_USART1_RI;
	stcIrqRegiCfg.enIRQn 		= Int010_IRQn;
    stcIrqRegiCfg.pfnCallback 	= uart1_rx_callback;
    enIrqRegistration(&stcIrqRegiCfg);

    NVIC_SetPriority(stcIrqRegiCfg.enIRQn, 14);
    NVIC_ClearPendingIRQ(stcIrqRegiCfg.enIRQn);
    NVIC_EnableIRQ(stcIrqRegiCfg.enIRQn);

    /**------------------------- ���ô��� TX �ж� -------------------------**/
    MEM_ZERO_STRUCT(stcIrqRegiCfg);
	
	stcIrqRegiCfg.enIntSrc 		= INT_USART1_TI;
	stcIrqRegiCfg.enIRQn 		= Int011_IRQn;
    stcIrqRegiCfg.pfnCallback 	= uart1_tx_callback;
    enIrqRegistration(&stcIrqRegiCfg);

    NVIC_SetPriority(stcIrqRegiCfg.enIRQn, 14);
    NVIC_ClearPendingIRQ(stcIrqRegiCfg.enIRQn);
    NVIC_EnableIRQ(stcIrqRegiCfg.enIRQn);

    /**------------------------- ʹ�ܴ��ڹ��� -----------------------------**/
	USART_FuncCmd(M4_USART1, UsartRxInt, Enable);
    USART_FuncCmd(M4_USART1, UsartTxAndTxEmptyInt, Enable);
    USART_FuncCmd(M4_USART1, UsartRx, Enable);
    
    /**------------------------- ���ܴ��ڹ��� -----------------------------**/
    USART_FuncCmd(M4_USART1, UsartSilentMode, Disable);
    USART_FuncCmd(M4_USART1, UsartNoiseFilter, Disable);
    USART_FuncCmd(M4_USART1, UsartFracBaudrate, Disable);
    USART_FuncCmd(M4_USART1, UsartMulProcessor, Disable);
    USART_FuncCmd(M4_USART1, UsartSmartCard, Disable);
    USART_FuncCmd(M4_USART1, UsartCts, Disable);
}

int CLK_Init(void)
{
    stc_clk_sysclk_cfg_t    stcSysClkCfg;
    stc_clk_xtal_cfg_t      stcXtalCfg;
    stc_clk_mpll_cfg_t      stcMpllCfg;
    stc_sram_config_t       stcSramConfig;

    MEM_ZERO_STRUCT(stcSysClkCfg);
    MEM_ZERO_STRUCT(stcXtalCfg);
    MEM_ZERO_STRUCT(stcMpllCfg);
    MEM_ZERO_STRUCT(stcSramConfig);

    /* Set bus clk div. */
    stcSysClkCfg.enHclkDiv  = ClkSysclkDiv1;
    stcSysClkCfg.enExclkDiv = ClkSysclkDiv2;
    stcSysClkCfg.enPclk0Div = ClkSysclkDiv1;
    stcSysClkCfg.enPclk1Div = ClkSysclkDiv2;
    stcSysClkCfg.enPclk2Div = ClkSysclkDiv4;
    stcSysClkCfg.enPclk3Div = ClkSysclkDiv4;
    stcSysClkCfg.enPclk4Div = ClkSysclkDiv2;
    CLK_SysClkConfig(&stcSysClkCfg);

    /* Config Xtal and Enable Xtal */
    stcXtalCfg.enMode = ClkXtalModeOsc;
    stcXtalCfg.enDrv = ClkXtalLowDrv;
    stcXtalCfg.enFastStartup = Enable;
    CLK_XtalConfig(&stcXtalCfg);
    CLK_XtalCmd(Enable);

    /* sram init include read/write wait cycle setting */
    stcSramConfig.u8SramIdx = Sram12Idx | Sram3Idx | SramHsIdx | SramRetIdx;
    stcSramConfig.enSramRC = SramCycle2;
    stcSramConfig.enSramWC = SramCycle2;
    SRAM_Init(&stcSramConfig);

    /* flash read wait cycle setting */
    EFM_Unlock();
    EFM_SetLatency(EFM_LATENCY_5);
    EFM_Lock();

    /* MPLL config (XTAL / pllmDiv * plln / PllpDiv = 200M). */
    stcMpllCfg.pllmDiv = 1ul;
    stcMpllCfg.plln    = 50ul;
    stcMpllCfg.PllpDiv = 2ul;
    stcMpllCfg.PllqDiv = 2ul;
    stcMpllCfg.PllrDiv = 2ul;
    CLK_SetPllSource(ClkPllSrcXTAL);
    CLK_MpllConfig(&stcMpllCfg);
    /* Enable MPLL. */
    CLK_MpllCmd(Enable);

	/* Wait MPLL ready. */
    while(Set != CLK_GetFlagStatus(ClkFlagMPLLRdy))
    {
        ;
    }
    /* Switch driver ability */
    PWC_HS2HP();
    /* Switch system clock source to MPLL. */
    CLK_SetSysClkSource(CLKSysSrcMPLL);
	
	return 0;
}
